 #include<iostream>
#include<algorithm>
using namespace std;

/*===========================================================================================
 * The Vector template implements the following public procedures:
 *  1. size_t capacity();                   => Returns capacity of vector array
 *  2. size_t size();                       => Returns current size of vector
 *  3. void push(T x);                      => Insert element at the end of the vector
 *  4. void pop();                          => Delete element at the end of (non-empty) vector
 *  5. T front();                           => Return first element of (non-empty) vector
 *  6. T back();                            => Return last element of (non-empty) vector
 *  7. T operator [] (size_t i);            => Returns element at i-th position
 *  8. void sort(size_t low, size_t high);  => Sort the vector elements in ascending order
 * ==========================================================================================*/
template <class T> class Vector {
    public:
        /* Allocate memory for an array of c elements and initialize with x */
        Vector(size_t c, T x): totalCapacity(c), currentSize(c) {
            vec=new T[totalCapacity];
            for(size_t i=0; i<totalCapacity; i++)
                vec[i]=x;
        }

        /* Allocate memory for an array of c elements (default value 1) */
        Vector(size_t c=1): totalCapacity(c), currentSize(0) {
            vec=new T[totalCapacity];
        }

        /* Return the capacity of the vector */
        size_t capacity() {
            return totalCapacity;
        }

        /* Return the current size of the vector */
        size_t size() {
            return currentSize;
        }

        /* Insert x at the end of the array - if array is full, double the capacity first */
        void push(T x) {
            if(currentSize==totalCapacity) {
                /* Create a new array with double capacity and copy old array into it */
                T* tempVec=new T[(totalCapacity*=2)];
                for(size_t i=0; i<currentSize; i++)
                    tempVec[i]=vec[i];

                /* Delete old array and update vec */
                delete[] vec;
                vec=tempVec;
            }
            /* Put x at the end and increment size */
            vec[currentSize++]=x;
        }

        /* Delete the last element of the array if non-empty */
        void pop() {
            currentSize= currentSize>0 ? currentSize-1 : 0;
        }

        /* Return the first element of the array if non-empty */
        T front() {
            return currentSize>0 ? vec[0] : -1;
        }

        /* Return the last element of the array if non-empty */
        T back() {
            return currentSize>0 ? vec[currentSize-1] : -1;
        }

        /* Return the i-th element of the array if initialized */
        T operator [] (size_t i) {
            return i>=0 && i<currentSize ? vec[i] : -1;
        }

        /* Sort the elements of the array in ascending order */
        void sort(size_t low, size_t high) {
            /* If array has one or fewer elements it is already sorted or is invalid */
            if(high-low<=1) return;
            /* Obtain dividing position and perform quicksort on the left and right halves */
            size_t divider=partition(vec, low, high);
            sort(low, divider);
            sort(divider+1, high);
        }

        /* Deallocate memory used by vec array */
        ~Vector() {
            delete[] vec;
        }

    protected:
        /* Have the pivot (first element) go to the correct position, and ensure that every other element is on the correct side of the pivot */
        size_t partition(T* a, size_t low, size_t high) {
            /* Choose pivot as first element, and have i be the position after which all elements are greater than the pivot */
            size_t i=high-1;
            T pivot=a[low];
            for(size_t j=high-1; j>low; j--)
            /* If the current element is greater than pivot ensure it comes after i; note that j<=i always holds */
                if(a[j]>pivot)
                    swap(a[j], a[i--]);
            /* Bring pivot to correct position */
            swap(a[low], a[i]);
            /* Return dividing position */
            return i;
        }

        T* vec;
    private:
        size_t totalCapacity=1;
        size_t currentSize;
};

/*=========================================================================================
 * The Vector2 template implements
 *  void sort(size_t low, size_t high);     => Implements worst case nlogn quicksort
 * ========================================================================================*/
template<class T> class Vector2: public Vector<T> {
    public:
        /* We have the constructors internally use Vector constructors */
        Vector2(size_t c, T x): Vector<T>(c, x) {}
        Vector2(size_t c=1): Vector<T>(c) {}

        /* This implements quick sort with the additional feature that the pivot is chosen as a median of medians */
        void sort(size_t low, size_t high) {
            /* If there are one or fewer elements you are done */
            if(high<=low+1) return;

            /* Here we are finding median and choosing as our pivot- this happens in O(n) time */
            T pivot=findKth(this->vec, low, high, (high-low)/2);

            /* Here we are ensuring pivot is at the beginning so that partition function uses it as pivot as well - O(n) time*/
            for(size_t j=high-1; j>=low; j--) {
                if(this->vec[j]==pivot) {
                    swap(this->vec[j], this->vec[low]);
                    break;
                }
            }

            /* Now we actually partition the array - O(n) time */
            size_t divider=this->partition(this->vec, low, high);

            /* Recursively call on left and right halves */
            sort(low, divider);
            sort(divider+1, high);
        }
    private:
        /* Described in class by Prof. Pandu Rangan */
        /* This function finds the kth smallest element in O(n) time */
            T findKth(T* a, int low, int high, int k) {
            /* p is the number of groups of 5 in the data */
            int p=(high-low+4)/5;

            /* 'medians' stores the medians of the groups of 5 elements */
            T medians[p];

            /* Here we go through all groups of 5 elements and obtain their medians */
            for(int i=5; low+i<=high; i+=5) {
                selectionSort(a, low+i-5, low+i);
                medians[--p]=a[low+i-3];
            }

            /* If there are some remaining elements, we can simply choose the last element */
            if(p!=0) 
                medians[--p]=a[high-1];

            /* We choose the median of these medians as our pivot */
            T pivot= (p=(high-low+4)/5)==1 ? medians[0] : findKth(medians, 0, p, (p+1)/2);

            /* Next we ensure that the pivot is the first element so that it is so chosen by partition function */
            for(int j=high-1; j>=low; j--) {
                if(this->vec[j]==pivot) {
                    swap(this->vec[j], this->vec[low]);
                    break;
                }
            }

            /* The correct position of pivot is obtained from partition function */
            int divider=this->partition(a, low, high);

            /* Based on how many elements are less than the pivot, we can identify if the kth element is greater than or lesser than pivot */
            if(divider-low==k-1)
                return pivot;
            else if(divider-low>=k)
                return findKth(a, low, divider, k);
            else    
                return findKth(a, divider+1, high, k+low-divider-1);
        }

        /* For the portion where we sort 5 elements, we can use a simple algorithm like selection sort- it won't affect the complexity */
        void selectionSort(T* a, int low, int high) {
            for(int i=low; i<high-1; i++) {
                /* Every stage bring the next smallest element to the beginning */
                int minIndex=i;
                for(int j=low+1; j<high; j++)
                    if(a[minIndex]>a[j])
                        minIndex=j;
                swap(a[minIndex], a[i]);
            }
        }
};

int main() {
    /* initializeType checks how many of capacity and initialization value are provided- stored in parameter1 and parameter2 */
    int initializeType, delimiter=' ', parameter1, parameter2;

    /* "vector" is always read */
    char dummy[20];
    scanf("%s", dummy);

    /* Obtaining final delimiter after "vector" */
    while((delimiter=getc(stdin))==' ')
            ;
    ungetc(delimiter, stdin);

    /* If end of line reached, no parameters passed, else look for one or two parameters */
    if(delimiter=='\n') {
        initializeType=0;
    } else {
        /* Read in first parameter */
        scanf("%d", &parameter1);

        /* Obtain final delimiter after first parameter */
        while((delimiter=getc(stdin))==' ')
                ;
        ungetc(delimiter, stdin);

        /* If end of line reached, only one paramter, else two parameters */
        if(delimiter=='\n') {
            initializeType=1;
        } else {
            scanf("%d", &parameter2);
            initializeType=2;
        }
    }

    /* Check what constructor to call and initiate query process */
    Vector2<int>* vectorPointer;
    if(initializeType==0)
        vectorPointer=new Vector2<int>();
    else if(initializeType==1) 
        vectorPointer=new Vector2<int>(parameter1);
    else if(initializeType==2)
        vectorPointer=new Vector2<int>(parameter1, parameter2);

    /* Read in the number of queries and process as indicated! */
    int Q; cin>>Q;
    string input;
    for(int i=0; i<Q; i++) {
        cin>>input;
        if(input.compare("push")==0) {
            int x; cin>>x;
            vectorPointer->push(x);
        } else if(input.compare("pop")==0) {
            vectorPointer->pop();
        } else if(input.compare("front")==0) {
            cout<<vectorPointer->front()<<endl;
        } else if(input.compare("back")==0) {
            cout<<vectorPointer->back()<<endl;
        } else if(input.compare("capacity")==0) {
            cout<<vectorPointer->capacity()<<endl;
        } else if(input.compare("size")==0) {
            cout<<vectorPointer->size()<<endl;
        } else if(input.compare("sort")==0) {
            vectorPointer->sort(0, vectorPointer->size());
            for(int j=0; j<vectorPointer->size(); j++)
                cout<<(*vectorPointer)[j]<<" ";
            cout<<endl;
        } else {
            int in; cin>>in;
            cout<<(*vectorPointer)[in]<<endl;
        }
    }   
}